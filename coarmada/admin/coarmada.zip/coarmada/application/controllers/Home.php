<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('mbanner');
		$this->load->model('mrunning');
	}

	public function index()
	{	
		$data['running']	= $this->mrunning->getAllData();
		$data['images'] 	= $this->mbanner->getAllData();
		$this->load->view('content',$data);
	}

}

/* End of file Home.php */
/* Location: ./application/controllers/Home.php */