<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('mlogin');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$this->load->view('Admin/login');
	}

	public function signin(){

		$this->form_validation->set_error_delimiters('<div class="alerterror">', '</div>');
		$this->form_validation->set_rules('username','Username','trim|required');	
		$this->form_validation->set_rules('password','Password','trim|required');	
		
		if ($this->form_validation->run() == FALSE ){
			$this->index();	
		}
		else{

			$username 	= $this->input->post('username');
	        $password 	= md5($this->input->post('password'));
	        $cek		= $this->mlogin->cekLogin($username,$password);

	        if($cek->num_rows()>0){

				foreach ($cek->result() as $sess) {
					$data_session['status'] = 'login';
					$data_session['user_id'] = $sess->user_id;
					$data_session['nama_lengkap'] = $sess->nama_lengkap;
					$data_session['username'] = $sess->username;
					$data_session['level'] = $sess->level;
					$data_session['email'] = $sess->email;
					$data_session['avatar'] = $sess->avatar;
					$data_session['avatar_thumb'] = $sess->avatar_thumb;
					$this->session->set_userdata($data_session);
				}
				redirect('dashboard');
			
	        }
	        else{
	            redirect('admin/login','refresh');
		    }
		}
	}

	public function Signout(){
		$this->session->sess_destroy();
		redirect('login');
	}

}

/* End of file Login.php */
/* Location: ./application/controllers/Login.php */