
$(document).ready(function(){
	var table = $('#dtTable').DataTable();
});